
const express = require("express");
const fs = require("fs");
const jwt = require("jsonwebtoken");
const PDFDocument = require("pdfkit");

const app = express();
app.use(express.json());
app.use(express.static("public"));

const DB = "./db.json";
const SECRET = "ESCOLA_PRODUCAO";

if(!fs.existsSync(DB)){
 fs.writeFileSync(DB, JSON.stringify({
  users:[{email:"professor@escola.com",senha:"123456",role:"professor"}]
 }));
}

app.post("/api/login",(req,res)=>{
 const db=JSON.parse(fs.readFileSync(DB));
 const u=db.users.find(x=>x.email===req.body.email&&x.senha===req.body.senha);
 if(!u) return res.sendStatus(401);
 res.send({token:jwt.sign(u,SECRET),role:u.role});
});

app.get("/api/cert/:nome",(req,res)=>{
 const doc=new PDFDocument();
 res.setHeader("Content-Type","application/pdf");
 doc.pipe(res);
 doc.fontSize(20).text("CERTIFICADO",{align:"center"});
 doc.moveDown();
 doc.text(req.params.nome+" concluiu o curso.");
 doc.end();
});

app.listen(8080);
