
PORTAL DE CURSOS – VERSÃO MOBILE + PRODUÇÃO

📱 INTERFACE MOBILE-FIRST (responsiva)
☁️ PRONTO PARA HOSPEDAGEM REAL (Render / Railway)

========================
COMO RODAR LOCALMENTE
========================
docker-compose up --build
Acesse: http://localhost:8080

========================
HOSPEDAGEM EM PRODUÇÃO (RENDER)
========================
1. Crie conta em https://render.com
2. New Web Service
3. Conecte o GitHub
4. Build Command:
   npm install
5. Start Command:
   node server.js
6. Porta:
   8080

========================
LOGIN PADRÃO
========================
professor@escola.com
123456
